<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>ElectroMax - <?php echo isset($pageTitle) ? $pageTitle : 'Головна'; ?></title>
    <link rel="stylesheet" href="static/style.css">
</head>
<body>
    <header class="header">
        <h1 class="header-title">ElectroMax</h1>
        <nav>
            <ul class="nav-list">
                <li><a href="index.php" class="nav-link <?php echo ($activePage == 'index') ? 'active' : ''; ?>">Головна</a></li>
                <li><a href="catalog.php" class="nav-link <?php echo ($activePage == 'catalog') ? 'active' : ''; ?>">Каталог</a></li>
                <li><a href="discounts.php" class="nav-link <?php echo ($activePage == 'discounts') ? 'active' : ''; ?>">Акції</a></li>
                <li><a href="contacts.php" class="nav-link <?php echo ($activePage == 'contacts') ? 'active' : ''; ?>">Контакти</a></li>
                <li><a href="animation.php" class="nav-link <?php echo ($activePage == 'animation') ? 'active' : ''; ?>">JS Анімація</a></li>
                <li><a href="survey.php" class="nav-link <?php echo ($activePage == 'survey') ? 'active' : ''; ?>">Анкета</a></li>
                <li><a href="lab8.php" class="nav-link <?php echo ($activePage == 'lab8') ? 'active' : ''; ?>">API (JSON)</a></li>
                <li><a href="preview.php" class="nav-link <?php echo ($activePage == 'preview') ? 'active' : ''; ?>">Перегляд JSON</a></li>
                <li><a href="admin.php" class="nav-link <?php echo ($activePage == 'admin') ? 'active' : ''; ?>">Адмінка</a></li>
            </ul>
        </nav>
    </header>
    <main class="main-container">
