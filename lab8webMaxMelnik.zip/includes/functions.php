<?php
session_start();

// Підключення до бази даних SQLite (автоматично створює файл electramax.db)
function getDbConnection() {
    static $db = null;
    if ($db === null) {
        $dbFile = __DIR__ . '/../electramax.db';
        $db = new PDO("sqlite:" . $dbFile);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Створення таблиці для анкет, якщо вона ще не існує
        $db->exec("CREATE TABLE IF NOT EXISTS surveys (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            q1_device TEXT NOT NULL,
            q2_rating INTEGER NOT NULL,
            q3_comment TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");
    }
    return $db;
}

// Збереження анкети у базу даних
function saveSurvey($name, $email, $q1_device, $q2_rating, $q3_comment) {
    $db = getDbConnection();
    $stmt = $db->prepare("INSERT INTO surveys (name, email, q1_device, q2_rating, q3_comment, created_at) 
                          VALUES (:name, :email, :q1_device, :q2_rating, :q3_comment, datetime('now', 'localtime'))");
    $stmt->execute([
        ':name' => $name,
        ':email' => $email,
        ':q1_device' => $q1_device,
        ':q2_rating' => $q2_rating,
        ':q3_comment' => $q3_comment
    ]);
    return true;
}

// Отримання всіх збережених анкет
function getAllSurveys() {
    $db = getDbConnection();
    $stmt = $db->query("SELECT * FROM surveys ORDER BY created_at DESC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Видалення коментаря/запису за ID
function deleteSurvey($id) {
    $db = getDbConnection();
    $stmt = $db->prepare("DELETE FROM surveys WHERE id = :id");
    return $stmt->execute([':id' => $id]);
}

// Перевірка авторизації адміністратора
function isAdminLoggedIn() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

// Авторизація адміністратора
function loginAdmin($username, $password) {
    // Стандартні логін та пароль адміністратора: admin / admin123
    if ($username === 'admin' && $password === 'admin123') {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_user'] = $username;
        return true;
    }
    return false;
}

// Вихід адміністратора
function logoutAdmin() {
    unset($_SESSION['admin_logged_in']);
    unset($_SESSION['admin_user']);
    session_destroy();
}
?>