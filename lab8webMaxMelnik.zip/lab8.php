<?php
require_once 'includes/functions.php';

// ---------------------------------------------------------------
// Лабораторна робота №8: отримання даних JSON з REST API
// ---------------------------------------------------------------

const API_URL = 'http://lab.vntu.org/api-server/lab8.php';

/**
 * Отримання JSON-рядка з API за допомогою file_get_contents()
 * (якщо недоступна — через cURL).
 */
function fetchApiData(string $url, array $params): string
{
    // GET-параметри: user=student, pass=p@ssw0rd (http_build_query кодує @ як %40)
    $fullUrl = $url . '?' . http_build_query($params);

    if (ini_get('allow_url_fopen')) {
        $context = stream_context_create([
            'http' => ['method' => 'GET', 'timeout' => 10, 'ignore_errors' => true],
        ]);
        $response = @file_get_contents($fullUrl, false, $context);
        if ($response !== false) {
            return $response;
        }
    }

    // Запасний варіант: cURL
    if (function_exists('curl_init')) {
        $ch = curl_init($fullUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_FOLLOWLOCATION => true,
        ]);
        $response = curl_exec($ch);
        curl_close($ch);
        if ($response !== false) {
            return $response;
        }
    }

    throw new RuntimeException('Не вдалося отримати дані з API: ' . $fullUrl);
}

/**
 * Об'єднує всі записи про людей в один плоский масив.
 * Структура відповіді може бути:
 *  - списком записів:            [ {..}, {..} ]
 *  - об'єктом зі списками:       { "group1": [ {..} ], "group2": [ {..} ] }
 * Обидва варіанти зводяться до одного масиву.
 */
function collectRecords($data): array
{
    $records = [];
    if (!is_array($data)) {
        return $records;
    }
    foreach ($data as $key => $item) {
        if (is_array($item) && isAssoc($item)) {
            // Окремий запис (асоціативний масив)
            $records[] = $item;
        } elseif (is_array($item)) {
            // Вкладений список або група записів — розкриваємо рекурсивно
            $records = array_merge($records, collectRecords($item));
        }
    }
    return $records;
}

function isAssoc(array $arr): bool
{
    return $arr !== [] && array_keys($arr) !== range(0, count($arr) - 1);
}

/** Перетворює значення комірки на текст для виведення. */
function cellValue($value): string
{
    if (is_array($value)) {
        return json_encode($value, JSON_UNESCAPED_UNICODE);
    }
    if (is_bool($value)) {
        return $value ? 'так' : 'ні';
    }
    return (string)$value;
}

// ---------------------- Виконання ----------------------
$error   = null;
$records = [];
$columns = [];
$raw     = '';

try {
    // 1. Отримання JSON з API
    $raw = fetchApiData(API_URL, ['user' => 'student', 'pass' => 'p@ssw0rd']);

    // 2. Перетворення JSON у структури PHP
    $decoded = json_decode($raw, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new RuntimeException('Помилка розбору JSON: ' . json_last_error_msg());
    }

    // 3. Об'єднання всіх записів в один масив
    $records = collectRecords($decoded);

    // Колонки таблиці = об'єднання ключів усіх записів
    foreach ($records as $rec) {
        foreach (array_keys($rec) as $k) {
            if (!in_array($k, $columns, true)) {
                $columns[] = $k;
            }
        }
    }
} catch (Throwable $e) {
    $error = $e->getMessage();
}

$pageTitle  = 'Лабораторна №8';
$activePage = 'lab8';
require_once 'includes/header.php';
?>

<h2 class="section-title">Дані з REST API (JSON)</h2>
<p class="section-text">Джерело: <code><?php echo htmlspecialchars(API_URL); ?></code></p>

<?php if ($error): ?>
    <div style="color: #b91c1c; background: #fef2f2; padding: 12px; border-radius: 6px;">
        <?php echo htmlspecialchars($error); ?>
    </div>
<?php elseif (empty($records)): ?>
    <p class="section-text">API не повернуло жодного запису.</p>
<?php else: ?>
    <p class="section-text">Отримано записів: <strong><?php echo count($records); ?></strong></p>
    <table class="discounts-table">
        <thead>
            <tr>
                <th>№</th>
                <?php foreach ($columns as $col): ?>
                    <th><?php echo htmlspecialchars($col); ?></th>
                <?php endforeach; ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($records as $i => $rec): ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <?php foreach ($columns as $col): ?>
                        <td><?php echo htmlspecialchars(cellValue($rec[$col] ?? '')); ?></td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
