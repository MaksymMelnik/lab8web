<?php
require_once 'includes/functions.php';
$pageTitle = 'Каталог';
$activePage = 'catalog';
require_once 'includes/header.php';
?>
<h2 class="section-title">Каталог товарів зі знижками</h2>
<ul class="catalog-list">
    <li class="catalog-item"><strong>Смартфони:</strong> Флагманські моделі та бюджетні рішення.</li>
    <li class="catalog-item"><strong>Ноутбуки:</strong> Для роботи, навчання та ігор.</li>
    <li class="catalog-item"><strong>Навушники:</strong> Бездротові та повнорозмірні моделі.</li>
    <li class="catalog-item"><strong>Смарт-годинники:</strong> Фітнес-трекери та розумні годинники.</li>
    <li class="catalog-item"><strong>Комп'ютерні аксесуари:</strong> Мишки, клавіатури, монітори.</li>
</ul>
<img class="content-image" src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=600&q=80" alt="Каталог товарів">
<?php require_once 'includes/footer.php'; ?>
