<?php
require_once 'includes/functions.php';
$pageTitle = 'Головна';
$activePage = 'index';
require_once 'includes/header.php';
?>
<h2 class="section-title">Ласкаво просимо до ElectroMax!</h2>
<p class="section-text">Ваш надійний магазин сучасної електроніки та цифрової техніки. У нас ви знайдете найновіші ґаджети за вигідними цінами.</p>

<h2 class="section-title">Великий розпродаж вересня!</h2>
<p class="section-text">Не пропустіть можливість придбати популярні товари зі знижками до 30%.</p>

<img class="content-image" src="https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=600&q=80" alt="Електроніка ElectroMax">
<?php require_once 'includes/footer.php'; ?>
