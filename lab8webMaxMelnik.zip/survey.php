<?php
// Підключення файлу із допоміжними функціями (наприклад, saveSurvey)
require_once 'includes/functions.php';

// Ініціалізація змінних для сповіщення та часу відправки
$message = null;
$submitted_time = null;

// Перевірка, чи була форма відправлена методом POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Отримання та очищення (видалення зайвих пробілів) введених даних
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    
    // Отримання відповідей на запитання анкети (із значеннями за замовчуванням)
    $q1_device = $_POST['q1_device'] ?? 'Не вказано';
    $q2_rating = (int)($_POST['q2_rating'] ?? 5); // Приведення до цілого числа
    $q3_comment = trim($_POST['q3_comment'] ?? '');

    // Обов'язкова перевірка: ім'я та email не повинні бути порожніми
    if (!empty($name) && !empty($email)) {
        // Збереження даних анкети у базі даних через функцію saveSurvey
        if (saveSurvey($name, $email, $q1_device, $q2_rating, $q3_comment)) {
            // Фіксація поточного часу відправки
            $submitted_time = date('Y-m-d H:i:s');
            // Формування повідомлення про успішне збереження (із захистом від XSS через htmlspecialchars)
            $message = "Дякуємо, " . htmlspecialchars($name) . "! Вашу анкету успішно збережено у базі даних.";
        }
    }
}

// Налаштування метаданих сторінки для шапки сайту
$pageTitle = 'Анкета';
$activePage = 'survey';

// Підключення спільного файлу шапки (header)
require_once 'includes/header.php';
?>

<!-- Заголовок розділу -->
<h2 class="section-title">Опитування якості обслуговування ElectroMax</h2>

<!-- Виведення повідомлення про успішне відправлення forms, якщо воно існує -->
<?php if ($message): ?>
    <div style="padding: 15px; background-color: #e0f2fe; color: #0369a1; border-radius: 8px; margin-bottom: 20px;">
        <p><strong><?php echo $message; ?></strong></p>
        <p>Дата та час заповнення: <strong><?php echo $submitted_time; ?></strong></p>
    </div>
<?php endif; ?>

<!-- Форма опитування -->
<form action="survey.php" method="POST" class="contact-form">
    <!-- Поле: Ім'я -->
    <div class="form-group">
        <label class="form-label">Ваше ім'я *:</label>
        <input type="text" name="name" class="form-input" required>
    </div>

    <!-- Поле: Email -->
    <div class="form-group">
        <label class="form-label">Ваш Email *:</label>
        <input type="email" name="email" class="form-input" required>
    </div>

    <!-- Запитання 1: Вибір категорії товарів -->
    <div class="form-group">
        <label class="form-label">1. Яку категорію товарів ви купуєте найчастіше?</label>
        <select name="q1_device" class="form-input">
            <option value="Смартфони">Смартфони</option>
            <option value="Ноутбуки">Ноутбуки</option>
            <option value="Аксесуари">Комп'ютерні аксесуари</option>
        </select>
    </div>

    <!-- Запитання 2: Оцінка зручності сайту від 1 до 5 -->
    <div class="form-group">
        <label class="form-label">2. Оцініть зручність нашого сайту (від 1 до 5):</label>
        <input type="number" name="q2_rating" min="1" max="5" value="5" class="form-input">
    </div>

    <!-- Запитання 3: Побажання та коментарі -->
    <div class="form-group">
        <label class="form-label">3. Ваші побажання чи зауваження:</label>
        <textarea name="q3_comment" rows="3" class="form-textarea"></textarea>
    </div>

    <!-- Кнопка відправки форми -->
    <button type="submit" class="form-button">Надіслати анкету</button>
</form>

<?php 
// Підключення спільного файлу підвалу (footer)
require_once 'includes/footer.php'; 
?>