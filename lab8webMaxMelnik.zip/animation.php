<?php
require_once 'includes/functions.php';
$pageTitle = 'JS Анімація';
$activePage = 'animation';
require_once 'includes/header.php';
?>
<style>
    .anim-container {
        width: 100%;
        height: 320px;
        background-color: #0f172a;
        border-radius: 12px;
        position: relative;
        overflow: hidden;
        margin: 20px 0;
        box-shadow: inset 0 0 15px rgba(0,0,0,0.5);
    }
    .anim-box {
        width: 60px;
        height: 60px;
        background: linear-gradient(135deg, #38bdf8, #0284c7);
        border-radius: 50%;
        position: absolute;
        top: 130px;
        left: 20px;
        box-shadow: 0 0 15px #38bdf8;
    }
    .controls {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
        margin-bottom: 20px;
    }
    .btn {
        background-color: #38bdf8;
        color: #0f172a;
        border: none;
        padding: 10px 18px;
        border-radius: 6px;
        font-weight: 600;
        cursor: pointer;
        transition: 0.2s;
    }
    .btn:hover {
        background-color: #0284c7;
        color: #ffffff;
    }
</style>

<h2 class="section-title">Інтерактивна JavaScript Анімація</h2>
<p class="section-text">Керуйте рухом елемента за допомогою кнопок нижче:</p>

<div class="controls">
    <button class="btn" id="btnStart">Запустити</button>
    <button class="btn" id="btnPause">Пауза</button>
    <button class="btn" id="btnReverse">Змінити напрямок</button>
    <button class="btn" id="btnReset">Скинути</button>
</div>

<div class="anim-container" id="container">
    <div class="anim-box" id="box"></div>
</div>

<script src="static/script.js"></script>
<?php require_once 'includes/footer.php'; ?>
