<?php
require_once 'includes/functions.php';

$loginError = null;

// Обработка авторизации
if (isset($_POST['action']) && $_POST['action'] === 'login') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    if (!loginAdmin($username, $password)) {
        $loginError = 'Невірний логін або пароль!';
    }
}

// Обработка выхода
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    logoutAdmin();
    header('Location: admin.php');
    exit;
}

// Перевірка авторизації
if (isAdminLoggedIn()) {
    // Обробка видалення запису
    if (isset($_POST['action']) && $_POST['action'] === 'delete') {
        $deleteId = (int)($_POST['id'] ?? 0);
        if ($deleteId > 0) {
            deleteSurvey($deleteId);
        }
    }

    // Обробка експорту у JSON або CSV
    if (isset($_GET['export'])) {
        $surveys = getAllSurveys();
        $type = $_GET['export'];

        if ($type === 'json') {
            header('Content-Type: application/json; charset=utf-8');
            header('Content-Disposition: attachment; filename="surveys_export_' . date('Y-m-d') . '.json"');
            echo json_encode($surveys, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            exit;
        } elseif ($type === 'csv') {
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="surveys_export_' . date('Y-m-d') . '.csv"');
            $output = fopen('php://output', 'w');
            // Додаємо BOM для коректного відображення кирилиці в Excel
            fputs($output, "ï»¿");
            fputcsv($output, ['ID', "Ім'я", 'Email', 'Категорія', 'Оцінка', 'Коментар', 'Дата створення']);
            foreach ($surveys as $row) {
                fputcsv($output, $row);
            }
            fclose($output);
            exit;
        }
    }
}

$pageTitle = 'Адмін-панель';
$activePage = 'admin';
require_once 'includes/header.php';
?>

<h2 class="section-title">Адміністративна панель</h2>

<?php if (!isAdminLoggedIn()): ?>
    <!-- Форма авторизації -->
    <div style="max-width: 400px; margin: 30px auto; padding: 20px; background: #f8fafc; border-radius: 8px; border: 1px solid #cbd5e1;">
        <h3 style="margin-bottom: 15px; color: #0f172a;">Вхід для адміністратора</h3>
        
        <?php if ($loginError): ?>
            <div style="color: #b91c1c; background: #fef2f2; padding: 10px; border-radius: 6px; margin-bottom: 15px;">
                <?php echo htmlspecialchars($loginError); ?>
            </div>
        <?php endif; ?>

        <form action="admin.php" method="POST" class="contact-form" style="max-width: 100%;">
            <input type="hidden" name="action" value="login">
            <div class="form-group">
                <label class="form-label">Логін:</label>
                <input type="text" name="username" class="form-input" required>
            </div>
            <div class="form-group">
                <label class="form-label">Пароль:</label>
                <input type="password" name="password" class="form-input" required>
            </div>
            <button type="submit" class="form-button">Увійти</button>
        </form>
        <p style="margin-top: 10px; font-size: 13px; color: #64748b;">(За замовчуванням: <strong>admin</strong> / <strong>admin123</strong>)</p>
    </div>

<?php else: ?>
    <!-- Панель керування анкет -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <p>Вітаємо, <strong><?php echo htmlspecialchars($_SESSION['admin_user']); ?></strong>!</p>
        <div>
            <a href="admin.php?export=json" class="form-button" style="text-decoration: none; padding: 8px 12px; margin-right: 5px;">Експорт у JSON</a>
            <a href="admin.php?export=csv" class="form-button" style="text-decoration: none; padding: 8px 12px; background-color: #10b981; color: white; margin-right: 15px;">Експорт у CSV</a>
            <a href="admin.php?action=logout" style="color: #ef4444; font-weight: 600;">Вийти</a>
        </div>
    </div>

    <h3>Заповнені анкети користувачів</h3>
    
    <?php $surveys = getAllSurveys(); ?>
    <?php if (empty($surveys)): ?>
        <p style="margin-top: 15px; color: #64748b;">Анкет поки що немає.</p>
    <?php else: ?>
        <table class="discounts-table" style="margin-top: 15px;">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Ім'я / Email</th>
                    <th>Категорія</th>
                    <th>Оцінка</th>
                    <th>Коментар</th>
                    <th>Дата</th>
                    <th>Дії</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($surveys as $item): ?>
                    <tr>
                        <td><?php echo $item['id']; ?></td>
                        <td>
                            <strong><?php echo htmlspecialchars($item['name']); ?></strong><br>
                            <small style="color: #64748b;"><?php echo htmlspecialchars($item['email']); ?></small>
                        </td>
                        <td><?php echo htmlspecialchars($item['q1_device']); ?></td>
                        <td><strong><?php echo $item['q2_rating']; ?>/5</strong></td>
                        <td><?php echo nl2br(htmlspecialchars($item['q3_comment'])); ?></td>
                        <td><small><?php echo $item['created_at']; ?></small></td>
                        <td>
                            <form action="admin.php" method="POST" onsubmit="return confirm('Видалити цей запис?');" style="margin:0;">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
                                <button type="submit" style="background: #ef4444; color: white; border: none; padding: 6px 10px; border-radius: 4px; cursor: pointer;">Видалити</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
