<?php
require_once 'includes/functions.php';
$pageTitle = 'Акції';
$activePage = 'discounts';
require_once 'includes/header.php';
?>
<h2 class="section-title">Дати проведення акції та розміри знижок</h2>
<p class="section-text">Ознайомтеся з графіком знижок на вересень:</p>

<table class="discounts-table">
    <thead>
        <tr>
            <th>Дата</th>
            <th>Розмір знижки</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>15 вересня</td>
            <td>10%</td>
        </tr>
        <tr>
            <td>16 вересня</td>
            <td>15%</td>
        </tr>
        <tr>
            <td>17 вересня</td>
            <td>20%</td>
        </tr>
        <tr>
            <td>18 вересня</td>
            <td>30%</td>
        </tr>
    </tbody>
</table>
<?php require_once 'includes/footer.php'; ?>
