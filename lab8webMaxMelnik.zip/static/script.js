const box = document.getElementById('box');
const container = document.getElementById('container');

const btnStart = document.getElementById('btnStart');
const btnPause = document.getElementById('btnPause');
const btnReverse = document.getElementById('btnReverse');
const btnReset = document.getElementById('btnReset');

let positionX = 20;
let speed = 3;
let direction = 1;
let isRunning = false;
let animationId = null;

function animate() {
    const maxLeft = container.clientWidth - box.clientWidth - 20;
    positionX += speed * direction;

    if (positionX >= maxLeft) {
        positionX = maxLeft;
        direction = -1;
    } else if (positionX <= 20) {
        positionX = 20;
        direction = 1;
    }

    box.style.left = `${positionX}px`;

    if (isRunning) {
        animationId = requestAnimationFrame(animate);
    }
}

btnStart.addEventListener('click', () => {
    if (!isRunning) {
        isRunning = true;
        animationId = requestAnimationFrame(animate);
    }
});

btnPause.addEventListener('click', () => {
    isRunning = false;
    cancelAnimationFrame(animationId);
});

btnReverse.addEventListener('click', () => {
    direction *= -1;
});

btnReset.addEventListener('click', () => {
    isRunning = false;
    cancelAnimationFrame(animationId);
    positionX = 20;
    direction = 1;
    box.style.left = `${positionX}px`;
});
