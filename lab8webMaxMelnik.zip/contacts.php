<?php
require_once 'includes/functions.php';
$pageTitle = 'Контакти';
$activePage = 'contacts';
require_once 'includes/header.php';
?>
<h2 class="section-title">Контактна інформація</h2>
<p class="section-text"><strong>Адреса:</strong> м. Вінниця, вул. Соборна, 10</p>
<p class="section-text"><strong>Телефон:</strong> +380 (432) 00-00-00</p>
<p class="section-text"><strong>Email:</strong> info@electromax.ua</p>

<h3 class="section-title">Форма зворотного зв'язку</h3>
<form class="contact-form">
    <div class="form-group">
        <label for="name" class="form-label">Ваше ім'я:</label>
        <input type="text" id="name" name="name" class="form-input">
    </div>
    
    <div class="form-group">
        <label for="email" class="form-label">Ваш Email:</label>
        <input type="email" id="email" name="email" class="form-input">
    </div>
    
    <div class="form-group">
        <label for="message" class="form-label">Повідомлення:</label>
        <textarea id="message" name="message" rows="4" class="form-textarea"></textarea>
    </div>
    
    <input type="submit" value="Надіслати" class="form-button">
</form>
<?php require_once 'includes/footer.php'; ?>
