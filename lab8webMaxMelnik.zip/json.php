<?php
// Бонусне завдання 1: вивід усіх анкет з лабораторної №6 у форматі JSON.
// Анкети зберігаються в SQLite (таблиця surveys), тому парсинг текстових файлів не потрібен.
require_once 'includes/functions.php';

$surveys = getAllSurveys();

// Кожна анкета — окремий елемент масиву; ім'я, пошта та відповіді — окремі параметри
$result = [];
foreach ($surveys as $row) {
    $result[] = [
        'id'      => (int)$row['id'],
        'name'    => $row['name'],
        'email'   => $row['email'],
        'answers' => [
            'q1_category' => $row['q1_device'],
            'q2_rating'   => (int)$row['q2_rating'],
            'q3_comment'  => $row['q3_comment'],
        ],
        'created_at' => $row['created_at'],
    ];
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
