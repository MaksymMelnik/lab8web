<?php
require_once 'includes/functions.php';

// Бонусне завдання 3: отримання даних з json.php та виведення у HTML-таблицю.

// Абсолютна адреса json.php на тому ж сервері
$scheme  = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$dir     = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$jsonUrl = $scheme . '://' . $_SERVER['HTTP_HOST'] . $dir . '/json.php';

$error   = null;
$surveys = [];

try {
    $raw = false;
    if (ini_get('allow_url_fopen')) {
        $raw = @file_get_contents($jsonUrl);
    }
    if ($raw === false && function_exists('curl_init')) {
        $ch = curl_init($jsonUrl);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10]);
        $raw = curl_exec($ch);
        curl_close($ch);
    }
    if ($raw === false) {
        throw new RuntimeException('Не вдалося отримати дані з ' . $jsonUrl);
    }

    $surveys = json_decode($raw, true);
    if (json_last_error() !== JSON_ERROR_NONE || !is_array($surveys)) {
        throw new RuntimeException('Помилка розбору JSON: ' . json_last_error_msg());
    }
} catch (Throwable $e) {
    $error = $e->getMessage();
}

$pageTitle  = 'Перегляд анкет (JSON)';
$activePage = 'preview';
require_once 'includes/header.php';
?>

<h2 class="section-title">Анкети, отримані з json.php</h2>
<p class="section-text">Джерело: <code><?php echo htmlspecialchars($jsonUrl); ?></code></p>

<?php if ($error): ?>
    <div style="color: #b91c1c; background: #fef2f2; padding: 12px; border-radius: 6px;">
        <?php echo htmlspecialchars($error); ?>
    </div>
<?php elseif (empty($surveys)): ?>
    <p class="section-text">Анкет поки що немає.</p>
<?php else: ?>
    <table class="discounts-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Ім'я</th>
                <th>Email</th>
                <th>Категорія</th>
                <th>Оцінка</th>
                <th>Коментар</th>
                <th>Дата</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($surveys as $s): ?>
                <tr>
                    <td><?php echo (int)$s['id']; ?></td>
                    <td><?php echo htmlspecialchars($s['name']); ?></td>
                    <td><?php echo htmlspecialchars($s['email']); ?></td>
                    <td><?php echo htmlspecialchars($s['answers']['q1_category']); ?></td>
                    <td><?php echo (int)$s['answers']['q2_rating']; ?>/5</td>
                    <td><?php echo nl2br(htmlspecialchars((string)$s['answers']['q3_comment'])); ?></td>
                    <td><small><?php echo htmlspecialchars($s['created_at']); ?></small></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
